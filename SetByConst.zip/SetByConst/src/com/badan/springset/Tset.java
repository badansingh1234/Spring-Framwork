package com.badan.springset;

public interface Tset {
	void display();
}
