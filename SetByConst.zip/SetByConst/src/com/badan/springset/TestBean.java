package com.badan.springset;

import java.util.Set;

public class TestBean implements Tset {
	private Set<String> set;
	public TestBean(Set<String> set) {
		super();
		this.set = set;
	}
	@Override
	public void display() {
		System.out.println("Name => "+set);
	}

}
