package com.badan.springset;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class TestMain {
	public static void main(String[] args) {
		Resource resource=new FileSystemResource("TestCfg.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		Tset t=(Tset)factory.getBean("xyz");
		t.display();
	}
}

