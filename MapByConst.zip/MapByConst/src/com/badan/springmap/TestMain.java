package com.badan.springmap;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class TestMain {
	public static void main(String[] args) {
		Resource resource=new FileSystemResource("TestCfg.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		I1 i=(I1)factory.getBean("abc");
		i.show();
	}
}
