package com.badan.springmap;

import java.util.Map;

public class TestBean implements I1 {
	private Map<Integer,String> map;
	
	public TestBean(Map<Integer, String> map) {
		super();
		this.map = map;
	}

	@Override
	public void show() {
		System.out.println(map);
	}


}
