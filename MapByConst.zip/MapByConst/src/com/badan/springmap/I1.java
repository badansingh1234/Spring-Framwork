package com.badan.springmap;

public interface I1 {
	void show();
}
