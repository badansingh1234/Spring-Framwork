package com.badan.springuser;

public class Address {
	private String city;
	private String state;
	private Integer zipcode;
	public Address() {	}
	public Address(String city, String state, Integer zipcode) {
		super();
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", zipcode=" + zipcode + "]";
	}
	
}
