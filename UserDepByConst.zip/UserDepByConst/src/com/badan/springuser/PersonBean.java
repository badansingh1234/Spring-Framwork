package com.badan.springuser;

public class PersonBean implements Test {
	private String pname;
	private Address address;
		
	public PersonBean(String pname, Address address) {
		super();
		this.pname = pname;
		this.address = address;
	}
	@Override
	public void display() {
		System.out.println("PersonName=> "+pname);
		System.out.println("PersonAddress=> "+address);
	}

}
