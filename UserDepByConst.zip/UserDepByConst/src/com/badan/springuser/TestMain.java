package com.badan.springuser;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class TestMain {

	public static void main(String[] args) {
		Resource resource=new FileSystemResource("PersonCfg.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		PersonBean pb=(PersonBean)factory.getBean("tb");
		pb.display();
	}

}
