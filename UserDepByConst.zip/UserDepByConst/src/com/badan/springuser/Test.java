package com.badan.springuser;

public interface Test {
	void display();
}
