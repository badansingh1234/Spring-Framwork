package com.badan.springlist;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class StudentMain {
	public static void main(String[] args) {
		Resource resource =new FileSystemResource("StudentCfg.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		I1 iob=(I1)factory.getBean("abc");
		iob.show();
	}
}
