package com.badan.springlist;

import java.util.List;

public class StudentBean implements I1 {
	private List<Integer> list;
	
	public StudentBean(List<Integer> list) {
		super();
		this.list = list;
	}
	@Override
	public void show(){
		System.out.println("List Id=> "+list);
	}

}
