package com.badan.springlist;

public interface I1 {
	void show();
}
