package com.badan.basic;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class TestClient {

	public static void main(String[] args) {
		Resource resource=new FileSystemResource("config.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		//ApplicationContext ac=new ClassPathXmlApplicationContext("config.xml");
		//TestBean tb=(TestBean)ac.getBean("tb");
		TestBean tb=(TestBean)factory.getBean("tb");
		tb.display();
	}

}
