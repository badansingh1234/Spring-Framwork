package com.badan.basic;

public class TestBean implements Test{
	private String name;
	public void setName(String name)
	{
		this.name=name;
	}
	@Override
	public void display() {
		System.out.println("Name is => "+name);	}

}
