package com.badan.basic;

public interface Test {
	void display();
	
}
