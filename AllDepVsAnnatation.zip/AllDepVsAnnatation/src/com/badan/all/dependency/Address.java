package com.badan.all.dependency;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Address {
	@Value("420")
	private Integer hNo;
	@Value("Komal Resdency")
	private String hName;
	@Value("Mathura")
	private String city;
	@Value("281405")
	private Integer pincode;
	
	@Override
	public String toString() {
		return "Address [hNo=" + hNo + ", hName=" + hName + ", city=" + city + ", pincode=" + pincode + "]";
	}	
}
