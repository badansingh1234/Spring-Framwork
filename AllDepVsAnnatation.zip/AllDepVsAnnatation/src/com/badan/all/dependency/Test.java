package com.badan.all.dependency;

public interface Test {
	void dispaly();
}
