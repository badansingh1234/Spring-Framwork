package com.badan.all.dependency;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TestBean implements Test {
	@Value("BadaN Singh")
	private String name;
	@Value("123")
	private Byte bt;
	@Value("12355")
	private Short st;
	@Value("M")
	private Character ch;
	@Value("62145")
	private Integer it;
	@Value("8307152871")
	private Long lg;
	@Value("2365.5")
	private Float ft;
	@Value("2658.26")
	private Double db;
	@Value("false")
	private Boolean bl;
	@Autowired
	private Address address;
	@Autowired
	private Date date;
	@Value("Badan Singh,jai Kumar,Tushar Yadav")
	private List<String> list;
//	@Value("401,301,201,101,501")
//	private Set<Integer> set;
	
	@Override
	public void dispaly() {
		System.out.println("Name is   => "+name);
		System.out.println("Byte is   => "+bt);
		System.out.println("Short is  => "+st);
		System.out.println("Char is   => "+ch);
		System.out.println("Integer is=> "+it);
		System.out.println("Long is   => "+lg);
		System.out.println("Float is  => "+ft);
		System.out.println("Double is => "+db);
		System.out.println("Boolean is => "+bl);
		System.out.println("-----------Address--------");
		System.out.println(address);
		System.out.println("-----------Date--------");
		System.out.println(date);
		System.out.println("--------list-----------");
		Iterator<String> itr1=list.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
//		System.out.println("--------Set-----------");
//		Iterator<Integer> itr2=set.iterator();
//		while(itr2.hasNext())
//		{
//			System.out.println(itr2.next());
//		}
	}

}
