package com.badan.all.dependency;

import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.badan.all.dependency")
public class MyConfig {
	@Bean
	public Date getDateObject()
	{
		return new Date();
	}
}
