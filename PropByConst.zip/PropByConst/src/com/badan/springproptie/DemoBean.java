package com.badan.springproptie;

import java.util.Properties;

public class DemoBean implements I1 {
	private Properties props;
	public DemoBean(Properties props) {
		super();
		this.props = props;
	}
	@Override
	public void display() {
		System.out.println(props);
	}

}
