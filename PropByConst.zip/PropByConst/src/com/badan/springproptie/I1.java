package com.badan.springproptie;

public interface I1 {
	void display();
}
