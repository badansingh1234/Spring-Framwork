package com.badan.springproptie;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class DemoMain {
	public static void main(String[] args) {
		Resource resource=new FileSystemResource("config.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		I1 i=(I1)factory.getBean("xyz");
		i.display();
	}
}
