package com.badan.all.dependency;

public class Address {
	private String hName;
	private String city;
	private Integer pin;
	public Address(String hName, String city, Integer pin) {
		super();this.hName = hName;this.city = city;this.pin = pin;
	}
	@Override
	public String toString() {
		return "Address [hName=" + hName + ", city=" + city + ", pin=" + pin + "]";
	}
}
