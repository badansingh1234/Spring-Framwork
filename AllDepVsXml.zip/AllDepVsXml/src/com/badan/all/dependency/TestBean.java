package com.badan.all.dependency;

import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class TestBean implements Test {
	private Byte bt;
	private Short st;
	private Character ch;
	private Integer no;
	private Long ln;
	private Float ft;
	private Double db;
	private Boolean bl;
	private Address address;
	private Date date;
	private List<String> list;
	private Set<Integer> set;
	private Map<Integer,String> map;
	private Properties prop;
	
	public TestBean(Byte bt, Short st, Character ch, Integer no, Long ln, Float ft, Double db, Boolean bl,Address address, Date date, List<String> list, Set<Integer> set, Map<Integer, String> map,Properties prop) {super();this.bt = bt;this.st = st;this.ch = ch;this.no = no;this.ln = ln;this.ft = ft;this.db = db;	this.bl = bl;this.address = address;this.date = date;this.list = list;this.set = set;this.map = map;this.prop = prop;	}

	@Override
	public void show() {
		System.out.println("--------Wrapper Class--------------");
		System.out.println("Byte=>      "+bt);
		System.out.println("Short=>     "+st);
		System.out.println("Character=> "+ch);
		System.out.println("Integer=>   "+no);
		System.out.println("Long=>      "+ln);
		System.out.println("Float=>     "+ft);
		System.out.println("Double=>    "+db);
		System.out.println("Boolean=>   "+bl);
		System.out.println("--------Address--------------");
		System.out.println(address);
		System.out.println("--------Predefine object--------------");
		System.out.println(date);
		System.out.println("------------list----------");
		Iterator<String> itr1=list.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
		System.out.println("------------set----------");
		Iterator<Integer> itr2=set.iterator();
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
		}
		System.out.println("------------Map----------");
		Set s=map.entrySet();
		Iterator itr3=s.iterator();
		while(itr3.hasNext())
		{
			System.out.println(itr3.next());
		}
		System.out.println("------------Properties ----------");
		Enumeration em=prop.elements();
		while(em.hasMoreElements())
		{
			System.out.println(em.nextElement());
		}
	}
	
}
