package com.spring.dao;

import java.util.List;

import com.spring.pojo.Person;

public interface Operation {
	//dml query ke liye jdbctemplate ke pass update 
	int add(Person person);
	int update(Person person);
	int delete(int personNo);
	//dql for all -jdbcTemplate ke pass query,queryForObject,
	
	
	List<Person> findAll();
	
}
