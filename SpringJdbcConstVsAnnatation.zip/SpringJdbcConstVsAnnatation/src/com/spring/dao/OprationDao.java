package com.spring.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.pojo.Person;

public class OprationDao implements Operation {
	private JdbcTemplate jdbcTemplate;
	
	//public OprationDao() {}

	public OprationDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int add(Person person) {
		String query="insert into person values(?,?,?)";
		return jdbcTemplate.update(query,person.getNo(),person.getName(),person.getPhone());
	}
	@Override
	public int update(Person person) {
		String query="update person set name=?,phone=? where no=?";
		return jdbcTemplate.update(query,person.getName(),person.getPhone(),person.getNo());
	}
	@Override
	public int delete(int personNo) {
		String query="delete from person where no=?";
		return jdbcTemplate.update(query,personNo);
	}
	
	@Override
	public List<Person> findAll() {
		String query="select*from person";
		List<Person> list=this.jdbcTemplate.query(query, new PersonMapper());
		return list;
	}	
}
