package com.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.spring.dao.Operation;
import com.spring.dao.OprationDao;
import com.spring.pojo.Person;

public class TestClient {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(PersonCfg.class);
		Operation o=ac.getBean(OprationDao.class);
		
		
		
		//FindAll
//		List<Person> list=o.findAll();
//		System.out.println(list);
//		for(Person p:list)
//		{
//			System.out.println("No=> "+p.getNo());
//			System.out.println("Name=> "+p.getName());
//			System.out.println("Phone=> "+p.getPhone());
//		}
		
		//DELETE
//		int r=o.delete(102);
//		System.out.println(r+" row deleted");
		
		//UPADTE
//		Person person =new Person();
//		person.setNo(102);
//		person.setName("Tushar Yadav");
//		person.setPhone(2655996655l);
//		
//		int r=o.update(person);
//		System.out.println(r+" row added");
		
		//INSERT  by setter 
//		Person person=new Person();
//		person.setNo(103);
//		person.setName("Manish Kumar");
//		person.setPhone(9865321425L);
//		int r=o.add(person);
//		System.out.println(r+" row added");
		
		//Insert by Constructor
		//Person person1=new Person(102,"Tushar Yadav",9607152878L);
//		int r=o.add(person1);
//		System.out.println(r+" row added");
	}

}
