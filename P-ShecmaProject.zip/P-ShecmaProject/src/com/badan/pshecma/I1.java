package com.badan.pshecma;

public interface I1 {
	void show();
}
