package com.badan.pshecma;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class Main {
	public static void main(String[] args) {
		Resource resource=new FileSystemResource("Config.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		Bean b=(Bean)factory.getBean("tb");
		b.show();
	}
}
