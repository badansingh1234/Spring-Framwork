package com.badan.pshecma;

public class Bean implements I1 {
	private Integer no;
	private String name;
	private Float salary;
	public void setNo(Integer no) {
		this.no = no;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setSalary(Float salary) {
		this.salary = salary;
	}
	@Override
	public void show() {
		System.out.println("No=> "+no+" Name=> "+name+" Salary=> "+salary);
	}

}
