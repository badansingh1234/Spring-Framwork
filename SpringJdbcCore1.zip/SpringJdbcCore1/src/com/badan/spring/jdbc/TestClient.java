package com.badan.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.badan.spring.dao.StudentDao;
import com.badan.spring.dao.StudentDaoImpl;
import com.badan.spring.pojo.Student;

public class TestClient {

	public static void main(String[] args) {
		System.out.println("Project stareted--------");
		ApplicationContext ac=new ClassPathXmlApplicationContext("config.xml");
		
		StudentDao sd=ac.getBean("studentDao",StudentDaoImpl.class);
		List<Student> list=sd.findAll();
		System.out.println(list);
		for(Student st:list)
		{
			System.out.println("Id=> "+st.getId());
			System.out.println("Name=> "+st.getName());
			System.out.println("city=> "+st.getCity());
		}
		
		//delete record
//		StudentDao sd=ac.getBean("studentDao",StudentDaoImpl.class);
//		int r=sd.delete(105);
//		System.out.println(r+" row is delete");
		
//		StudentDao sd=ac.getBean("studentDao",StudentDao.class);
//		//update record
//		Student st=new Student();
//		st.setId(103);
//		st.setName("Kritika Pal");
//		st.setCity("Gaziabad");
//		
//		int r=sd.change(st);
//		System.out.println(r+" row is update");
		
		
//		StudentDao sd=	ac.getBean("studentDao",StudentDao.class);
//		//insert query
//		Student st=new Student();
//		st.setId(105);
//		st.setName("Rishabh Singhal");
//		st.setCity("Noida");
//		
//		int r=sd.insert(st);
//		System.out.println(r+" is added");
				
//		JdbcTemplate jt1 =	ac.getBean("jdbcTemplate",JdbcTemplate.class);
//		String query="insert into student(id,name,city) values(?,?,?)";
//		int result=	jt1.update(query,103,"Manish Kuamar","BulandShahar");
//		System.out.println(result+" row is added");
	}
}
