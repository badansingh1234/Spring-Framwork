package com.badan.spring.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.badan.spring.pojo.Student;

public class StudentDaoImpl implements StudentDao {
	private JdbcTemplate jdbcTemplate;
	@Override
	public int insert(Student stduent) {
		//INSERT
		String query="insert into student(id,name,city) values(?,?,?)";
		int res = this.jdbcTemplate.update(query,stduent.getId(),stduent.getName(),stduent.getCity());
		return res;
	}
	@Override
	public int change(Student stduent) {
		//UPDATE
		String qurey="update student set name=?,city=? where id=?";
		int r = this.jdbcTemplate.update(qurey,stduent.getName(),stduent.getCity(),stduent.getId());
		return r;
	}
	@Override
	public int delete(int studentId) {
		//DELETE
		String query="delete from student where id=?";
		int r=this.jdbcTemplate.update(query,studentId);
		return r;
	}
	@Override
	public List<Student> findAll() {
		String query="select*from student";
		List<Student> list=this.jdbcTemplate.query(query,new StudentMapper());
		return list;
	}	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
		
}
