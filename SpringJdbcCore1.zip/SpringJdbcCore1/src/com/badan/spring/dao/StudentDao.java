package com.badan.spring.dao;

import java.util.List;

import com.badan.spring.pojo.Student;

public interface StudentDao {
	//dml query(insert,update,delete)->JdbcTemplate-> update() okk..
	int insert(Student stduent);
	int change(Student stduent);
	int delete(int studentId);
	//dql query(all, two ,one)object ke liye
	List<Student> findAll();
}
