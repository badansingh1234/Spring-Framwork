package com.spring.pojo;

public class Person {
	private Integer no;
	private String name;
	private Long phone;
	
	public Person() {}
	public Person(Integer no, String name,Long phone) {this.no = no;this.name = name;this.phone = phone;}
	
	public Integer getNo() {
		return no;
	}
	public void setNo(Integer no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "Person [no=" + no + ", name=" + name + ", phone=" + phone + "]";
	}
}
